import React, { useState } from 'react';
import { View, TextInput, StyleSheet, Text, Alert } from 'react-native';

const KeyboardType = () => {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [password, setPassword] = useState('');
  const [text, setText] = useState('');

  const validateEmail = (text) => {
    setEmail(text);
    if (!text.includes('@')) {
      setError('Invalid Email Address!');
    } else {
      setError('');
    }
  };

  const handleSubmit = () => {
    Alert.alert('Submitted Text:', `Email: ${email}\nPhone: ${phone}\nPassword: ${password}\nText: ${text}`);
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="First Name"
        onChangeText={(text) => setEmail(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Last Name"
        onChangeText={(text) => setPhone(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter Email"
        keyboardType="email-address"
        onChangeText={validateEmail}
      />
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      <TextInput
        style={styles.input}
        placeholder="Phone Number"
        keyboardType="phone-pad"
        onChangeText={(text) => setPhone(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter Password"
        secureTextEntry={true}
        onChangeText={(value) => setPassword(value)}
      />
      <TextInput
        style={styles.input}
        placeholder="Press Enter After Typing..."
        onChangeText={(value) => setText(value)}
        returnKeyType="done"
        onSubmitEditing={handleSubmit}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    height: 40,
    width: '80%',
    borderColor: 'gray',
    paddingHorizontal: 10,
    marginVertical: 10,
    borderWidth: 1,
    borderRadius: 5,
  },
  errorText: {
    marginTop: 10,
    fontSize: 18,
    color: 'red',
  },
});

export default KeyboardType;